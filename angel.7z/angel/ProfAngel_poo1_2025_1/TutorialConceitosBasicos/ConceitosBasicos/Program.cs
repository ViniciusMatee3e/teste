﻿using Heranca;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConceitosBasicos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Pessoa Joao = new Pessoa();
            //Console.WriteLine("Entre Com o Nome: ");
            //Joao.PessoaNome = Console.ReadLine();

            //Console.WriteLine();

            PessoaFisica J = new PessoaFisica();
            PessoaFisica J1 = new PessoaFisica("Xerox Cia");

        }
    }
}
