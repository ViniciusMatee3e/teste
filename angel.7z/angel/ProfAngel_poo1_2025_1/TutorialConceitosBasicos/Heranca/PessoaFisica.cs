﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heranca
{
    public class PessoaFisica:Pessoa
    {
        public PessoaFisica()
        {
            this.PessoaNome = "Pessoa Fisica";
        }

        public PessoaFisica(string NomeF)
        {
            this.PessoaNome = NomeF;
        }
        public void PrintNome()
        {
            Console.WriteLine(this.PessoaNome);
        }
    }
}
