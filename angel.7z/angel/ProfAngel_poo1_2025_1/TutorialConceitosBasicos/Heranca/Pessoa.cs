﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heranca
{
    public class Pessoa
    {
        public int Id { get; set; }
        public string PessoaNome { get; set; }

        public Pessoa()
        {
            this.PessoaNome = "Pessoa";
        }
    }
}
