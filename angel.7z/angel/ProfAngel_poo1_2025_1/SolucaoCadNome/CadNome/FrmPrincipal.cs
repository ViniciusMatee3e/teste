﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CadNome
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void nomesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 J1 = new Form1();
            J1.MdiParent = this;
            J1.Show();
              
        }
    }
}
