<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CineBR</title>
    <link rel="stylesheet" href="../Assets/style.css">
</head>
<body>
<div class="form">
    <form action="../controller/cadastro.cinebr.php"  method="post">
        <br>
    <input type="text" name="nome" placeholder="Digite o nome do usuário" required>
    <input type="email" name="email" placeholder="Digite seu email" required>
    <input type="password" name="senha" placeholder="Digite sua senha" required>
    <button type="submit">Cadastrar</button>
    </form>
</div>
</body>
</html>