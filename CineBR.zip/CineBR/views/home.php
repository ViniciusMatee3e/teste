<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="../Assets/style copy.css">
    <link rel="stylesheet" href="../Assets/media-query.css">
    <link rel="stylesheet" href="../Assets/style.css">]
    <link rel="icon" href="../Assets/img/icone.jpg">
</head>
<body>
    <main>
        <section id="login">
            <aside id="imagem">
            </aside>
            <article id="formulario">
                <h1>Login</h1>
                <p>Seja bem-vindo(a) novamente. Faça seu login para acessar sua conta.</p>
                <form action="../controller/login.php" method="post" autocomplete="on">
                    <div class="campo">
                        <span class="material-icons">person</span>
                        <input type="email" name="email" placeholder="E-mail..." autocomplete="email" required>
                        <label for="ilogin">Login</label>
                    </div>
                    <div class="campo">
                        <span class="material-icons">vpn_key</span>
                        <input type="password" name="senha"  placeholder="Senha..." autocomplete="current-password" required minlength="6">
                        <label for="isenha">Senha</label>
                    </div>
                    <div class="cada">
   <a href="cadastro.cineBr.php" target="_blank">Cadastrar</a>
   </div>
                    <input type="submit" value="Entrar">
                    <a href="#" class="botao">Esqueci a senha <i class="material-icons">mail</i></a>
                </form>
            </article>
        </section>
    </main>
</body>
</html>