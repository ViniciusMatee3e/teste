<?php
class FilmeDao {

    public static function cadastrar($filmes) {
        require_once '../Model/conexao.php';
        $conexao = conexao::conectar();

        $queryInsert = "INSERT INTO movies(nomeFilme, time, date, genero, capa)
                        VALUES (?, ?, ?, ?, ?)";

        $preparatementStatement = $conexao->prepare($queryInsert);

        $preparatementStatement->bindValue(1, $filmes->getNomeFilme());
        $preparatementStatement->bindValue(2, $filmes->getTime());
        $preparatementStatement->bindValue(3, $filmes->getDate());
        $preparatementStatement->bindValue(4, $filmes->getGenero());
        $preparatementStatement->bindValue(5, $filmes->getCapa());

        try {
            $preparatementStatement->execute();
            echo '
                <script>
                    alert("Cadastrou");
                    window.location="../admin/admin.php"
                </script>
            ';
        } catch (Exception $e) {
            echo('
            <script>
                alert("Ocorreu um erro ao enviar");
            </script>
        ');
            echo $e;
        }
    }
}
?>