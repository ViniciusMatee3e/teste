<?php
class UsuarioDao {
public static function verificarCadastro($usuarios){
        require_once '../model/Conexao.php';


        $conexao = Conexao::conectar();
        $querySelect="SELECT    id FROM usuarios
                            WHERE email='".$usuarios->getEmail()."' AND senha = '".$usuarios->getSenha()."'";
                             try{
                                $resultado =$conexao->query($querySelect);
                                $usuarioObject = $resultado->fetchAll();

            
                                return $usuarioObject;
                                echo('
                                <script>
                                    alert("cliente logado com sucesso!");
                                </script>
                                ');
                                return 'Cadastrou';
                                
                            }catch(Exception $e){
                                echo('
                                    <script>
                                        alert("Ocorreu um erro ao se logar");
                        </script>
                         ');
                                echo($e);
                            }
                        }
    public static function verificarLogin($usuarios){
        require_once '../model/Conexao.php';


        $conexao = Conexao::conectar();
        $querySelect="SELECT    id FROM usuarios
                            WHERE email='".$usuarios->getEmail()."' AND senha = '".$usuarios->getSenha()."'";
                             try{
                                $resultado =$conexao->query($querySelect);
                                $usuarioObject = $resultado->fetchAll();

            
                                return $usuarioObject;
                                echo('
                                <script>
                                    alert("cliente logado com sucesso!");
                                </script>
                                ');
                                return 'Cadastrou';
                                
                            }catch(Exception $e){
                                echo('
                                    <script>
                                        alert("Ocorreu um erro ao se logar");
                        </script>
                         ');
                                echo($e);
                            }
                        }
    public static function cadastrar($usuarios) {
        require_once '../Model/conexao.php';

        $conexao = conexao::conectar();

        $queryInsert = "INSERT INTO usuarios(nome, email, senha)
                        VALUES (?, ?, ?)";

        $preparatementStatement = $conexao->prepare($queryInsert);

        $preparatementStatement->bindValue(1, $usuarios->getNome());
        $preparatementStatement->bindValue(2, $usuarios->getEmail());
        $preparatementStatement->bindValue(3, $usuarios->getSenha());

        try {
            $preparatementStatement->execute();
            echo '
                <script>
                    alert("Cadastrou");
                </script>
            ';
            return 'Cadastrou';
        } catch (Exception $e) {
            echo $e;
        }
    }
    
}
?>