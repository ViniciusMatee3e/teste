<?php

session_start();

if (empty($_SESSION['id'])) {
    echo ('
    <script>
        alert("Bem vindo a site CineBr o primeiro projeto idenpendente de Vinicius Mateus e victor hugo faça o cadastro ou Login para pode  melhor utilizar seus funcionamentos espero que gostem");
        window.location = "../views/home.php";
    </script>
    ');
}

?>