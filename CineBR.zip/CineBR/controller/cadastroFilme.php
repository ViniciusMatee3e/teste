<?php
    require_once '../dao/filmeDao.php';
    require_once '../Model/filme.php';;

    $nomeFilme = $_POST['nomeFilme'];
    $time = $_POST['time'];
    $date = $_POST['date'];
    $genero = $_POST['genero'];
    $capa = $_POST['capa'];

    $filmes = new filme();
 
    $filmes->setNomeFilme($nomeFilme);
    $filmes->setTime( $time );
    $filmes->setDate($date);
    $filmes->setGenero( $genero);
    $filmes->setCapa($capa);
  
 
   
    $FilmeDao = new FilmeDao();
    $FilmeDao->cadastrar($filmes);
    

 
?>