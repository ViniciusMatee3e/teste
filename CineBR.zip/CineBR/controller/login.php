<?php
    require_once '../dao/UsuarioDao.php';
    require_once '../Model/usuario.php';

    $email =$_POST['email'];
    $senha=$_POST['senha'];

    $usuario= new usuario();
    $usuario->setEmail($email);
    $usuario->setSenha($senha);

    $usuarioDao =new UsuarioDao();

    if($usuarioDao::verificarLogin($usuario)){
        $usuarioObject=$usuarioDao::verificarLogin($usuario);

     ;

        $id = $usuarioObject[0]['id'];

        session_start();
        $_SESSION['id']=$id;



        echo(
            '<script>
            alert("usuario logado")
            window.location="../views/cineBR.php"
            </script>'
        );
        }else{
        echo('
        <script>
            alert("Nao foi possível logar");
            window.location = "../views/home.php";
        </script>
        ');
    }


?>