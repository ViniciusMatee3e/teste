<?php
    require_once '../dao/UsuarioDao.php';
    require_once '../Model/usuario.php';

    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];


    $usuarios = new  usuario();

    $usuarios->setNome($nome);
    $usuarios-> setEmail($email);
    $usuarios->setSenha($senha) ;

    $usuarioDao = new usuarioDao();
    if($usuarioDao::cadastrar($usuarios)){
        $usuarioObject=$usuarioDao::verificarCadastro($usuarios);

     

        $id = $usuarioObject[0]['id'];

        session_start();
        $_SESSION['id']=$id;



        echo(
            '<script>
            alert("usuario logado")
            window.location="../views/cineBR.php"
            </script>'
        );
        }else{
        echo('
        <script>
            alert("Nao foi possível logar");
            window.location = "../views/home.php";
        </script>
        ');
    }
    
?>