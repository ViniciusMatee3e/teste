<?php
class filme{
    private $id;
    private $nomeFilme;
    private $time;
    private $date;
    private $genero;
    private $capa;



    public function getId() {
        return $this->id;
    }

    // Setter for $id
    public function setId($id) {
        $this->id = $id;
    }

  // Getter methods
  public function getNomeFilme()
  {
      return $this->nomeFilme;
  }

  public function getTime()
  {
      return $this->time;
  }

  public function getDate()
  {
      return $this->date;
  }

  public function getGenero()
  {
      return $this->genero;
  }

  public function getCapa()
  {
      return $this->capa;
  }

  // Setter methods
  public function setNomeFilme($nomeFilme)
  {
      $this->nomeFilme = $nomeFilme;
  }

  public function setTime($time)
  {
      $this->time = $time;
  }

  public function setDate($date)
  {
      $this->date = $date;
  }

  public function setGenero($genero)
  {
      $this->genero = $genero;
  }

  public function setCapa($capa)
  {
      $this->capa = $capa;
  }
}


?>