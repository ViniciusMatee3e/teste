<?php
 class usuario{
    private $id;
    private $nome;
    private $email;
    private $senha;

    
    // Getter for $id
    public function getId() {
        return $this->id;
    }

    // Setter for $id
    public function setId($id) {
        $this->id = $id;
    }

    // Getter for $nome
    public function getNome() {
        return $this->nome;
    }

    // Setter for $nome
    public function setNome($nome) {
        $this->nome = $nome;
    }

    // Getter for $email
    public function getEmail() {
        return $this->email;
    }

    // Setter for $email
    public function setEmail($email) {
        $this->email = $email;
    }

    // Getter for $senha
    public function getSenha() {
        return $this->senha;
    }

    // Setter for $senha
    public function setSenha($senha) {
        $this->senha = $senha;
    }
}
?>