function openModal() {
    const modal = document.getElementById("myModal");
    modal.style.display = "block";
  }
  
  function closeModal() {
    const modal = document.getElementById("myModal");
    modal.style.display = "none";
  }
  