<?php
session_start();

$user = $_POST['adm'] ?? '';
$password = $_POST['senha'] ?? '';

// Comparing each user separately with the accepted values
if (($user == 'vinicius' || $user == 'victor' || $user == 'Pietro' || $user == 'jean') && $password == '0110') {
    echo '<script>
        alert("adm logado");
        window.location="admin.php";
        </script>';

    $_SESSION['adm'] = $user;
    $_SESSION['senha'] = $password;
} else {
    echo '<script>
        alert("adm nao logado");
        window.location="index.php";
        </script>';
}
?>
